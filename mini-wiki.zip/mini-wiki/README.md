# Smart Wiki 项目结构

```text
mini-wiki/
├─ index.html                 # 网站首页
├─ server.mjs                # 后端服务器与 API
├─ package.json              # 项目配置
├─ START-SMART-WIKI.cmd      # 启动服务器
├─ RESTART-SMART-WIKI.cmd    # 重启服务器
├─ STOP-SMART-WIKI.cmd       # 停止服务器
├─ pages/                    # 登录、后台、知识库、工具和游戏页面
├─ css/                      # 全站及各功能页面样式
├─ js/                       # 前端交互与各功能脚本
├─ assets/                   # Logo、图标与文章配图
├─ data/                     # 文章、用户、评论、消息和学习记录
├─ scripts/                  # 服务管理与局域网配置脚本
└─ legacy/                   # 不再使用但暂时保留的旧示例文件
```

## 常用修改位置

- 修改文章：`data/articles.json`
- 修改首页：`index.html`
- 修改其他页面：`pages/`
- 修改样式：`css/`
- 修改前端功能：`js/`
- 修改后端接口：`server.mjs`

服务器保留了旧网址兼容映射。例如访问 `/admin.html` 时，会自动读取 `pages/admin.html`；访问 `/style.css` 时，会自动读取 `css/style.css`。因此原有页面链接和浏览器书签无需修改。
